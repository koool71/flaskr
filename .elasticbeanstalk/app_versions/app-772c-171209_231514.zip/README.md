# flaskr
flask tutorial app

Learning flask so I can develop my own web apps easily. 
